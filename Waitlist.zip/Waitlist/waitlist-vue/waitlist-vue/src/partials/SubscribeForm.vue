<template>
  <div
    class="relative flex items-center justify-center gap-10 before:h-px before:w-full before:border-b before:[border-image:linear-gradient(to_right,transparent,theme(colors.indigo.300/.8),transparent)1] dark:before:[border-image:linear-gradient(to_right,transparent,theme(colors.indigo.300/.16),transparent)1] before:shadow-sm before:shadow-white/20 dark:before:shadow-none after:h-px after:w-full after:border-b after:[border-image:linear-gradient(to_right,transparent,theme(colors.indigo.300/.8),transparent)1] dark:after:[border-image:linear-gradient(to_right,transparent,theme(colors.indigo.300/.16),transparent)1] after:shadow-sm after:shadow-white/20 dark:after:shadow-none mb-11">
    <div class="w-full max-w-xs mx-auto shrink-0">
      <form class="relative">

        <!-- Border with dots in corners -->
        <div
          class="absolute -inset-3 bg-indigo-500/15 dark:bg-transparent dark:bg-gradient-to-b dark:from-gray-700/80 dark:to-gray-700/70 rounded-lg -z-10 before:absolute before:inset-y-0 before:left-0 before:w-[15px] before:bg-[length:15px_15px] before:[background-position:top_center,bottom_center] before:bg-no-repeat before:[background-image:radial-gradient(circle_at_center,theme(colors.indigo.500/.56)_1.5px,transparent_1.5px),radial-gradient(circle_at_center,theme(colors.indigo.500/.56)_1.5px,transparent_1.5px)] dark:before:[background-image:radial-gradient(circle_at_center,theme(colors.gray.600)_1.5px,transparent_1.5px),radial-gradient(circle_at_center,theme(colors.gray.600)_1.5px,transparent_1.5px)] after:absolute after:inset-y-0 after:right-0 after:w-[15px] after:bg-[length:15px_15px] after:[background-position:top_center,bottom_center] after:bg-no-repeat after:[background-image:radial-gradient(circle_at_center,theme(colors.indigo.500/.56)_1.5px,transparent_1.5px),radial-gradient(circle_at_center,theme(colors.indigo.500/.56)_1.5px,transparent_1.5px)] dark:after:[background-image:radial-gradient(circle_at_center,theme(colors.gray.600)_1.5px,transparent_1.5px),radial-gradient(circle_at_center,theme(colors.gray.600)_1.5px,transparent_1.5px)]"
          aria-hidden="true"></div>

        <div class="space-y-3">
          <div>
            <label class="sr-only" for="email">Email</label>
            <div class="relative">
              <div
                class="absolute inset-y-0 left-0 text-gray-500/70 dark:text-gray-400/70 pl-4 flex items-center pointer-events-none">
                <svg class="fill-current" xmlns="http://www.w3.org/2000/svg" width="16" height="14" fill="none">
                  <path
                    d="M14 0H2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2Zm0 12H2V5.723l5.504 3.145a.998.998 0 0 0 .992 0L14 5.723V12Zm0-8.58L8 6.849 2 3.42V2h12v1.42Z" />
                </svg>
              </div>
              <input id="email" class="form-input text-sm w-full pl-10 pr-4" type="email" placeholder="Your email..."
                required />
            </div>
          </div>
          <div>
            <button
              class="btn text-gray-100 bg-gray-900 hover:bg-gray-800 dark:text-gray-800 dark:bg-gray-100 dark:hover:bg-white w-full">Join
              The Waitlist</button>
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="max-w-3xl mx-auto">
    <div class="text-center">
      <!-- Avatars -->
      <ul class="flex justify-center -space-x-2 mb-4">
        <li>
          <img class="rounded-full" src="../images/avatar-01.jpg" width="32" height="32" alt="Avatar 01">
        </li>
        <li>
          <img class="rounded-full" src="../images/avatar-02.jpg" width="32" height="32" alt="Avatar 02">
        </li>
        <li>
          <img class="rounded-full" src="../images/avatar-03.jpg" width="32" height="32" alt="Avatar 03">
        </li>
        <li>
          <img class="rounded-full" src="../images/avatar-04.jpg" width="32" height="32" alt="Avatar 04">
        </li>
        <li>
          <img class="rounded-full" src="../images/avatar-05.jpg" width="32" height="32" alt="Avatar 05">
        </li>
      </ul>
      <p class="text-sm text-gray-500">Join the <span class="text-gray-700 dark:text-gray-200 font-medium">2.000+</span>
        members who have already signed up.</p>
    </div>
  </div>
</template>
