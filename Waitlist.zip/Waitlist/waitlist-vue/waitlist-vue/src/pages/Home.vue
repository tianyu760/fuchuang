<script setup>
import BgShapes from '../partials/BgShapes.vue'
import VerticalLines from '../partials/VerticalLines.vue'
import Header from '../partials/Header.vue'
import PageHeader from '../partials/PageHeader.vue'
import SubscribeForm from '../partials/SubscribeForm.vue'
import Footer from '../partials/Footer.vue'
</script>

<template>
  <div class="relative flex flex-col min-h-screen overflow-hidden supports-[overflow:clip]:overflow-clip">

    <BgShapes />
    <VerticalLines />

    <!-- Site header -->
    <Header />

    <!-- Page content -->
    <main class="grow">

      <section>
        <div class="pt-32 pb-12 md:pt-44 md:pb-20">
          <div class="px-4 sm:px-6">

            <PageHeader class="mb-12" title="The software that sparks your imagination" description="Our landing page template works on all devices, so you only have to set it up once, and get beautiful results forever.">
              Waitlist v1 <span class="text-gray-300 mx-1">·</span> Coming Soon
            </PageHeader>

            <SubscribeForm />

          </div>
        </div>
      </section>

    </main>

    <!-- Site footer -->
    <Footer />

  </div>
</template>
