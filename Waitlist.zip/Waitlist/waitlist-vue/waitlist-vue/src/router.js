import { createRouter, createWebHistory } from 'vue-router'
import Home from './pages/Home.vue'
import Updates from './pages/Updates.vue'
import Faq from './pages/Faq.vue'
import Contact from './pages/Contact.vue'

const routerHistory = createWebHistory()

const router = createRouter({
  scrollBehavior(to) {
    if (to.hash) {
      window.scroll({ top: 0 })
    } else {
      document.querySelector('html').style.scrollBehavior = 'auto'
      window.scroll({ top: 0 })
      document.querySelector('html').style.scrollBehavior = ''
    }
  },  
  history: routerHistory,
  routes: [
    {
      path: '/',
      component: Home
    },
    {
      path: '/updates',
      component: Updates
    },
    {
      path: '/faq',
      component: Faq
    },    
    {
      path: '/contact',
      component: Contact
    },    
  ]
})

export default router
