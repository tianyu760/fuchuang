package com.legal.ai.dto;

import lombok.Data;

import jakarta.validation.constraints.Email;

@Data
public class UserUpdateRequest {

    private String nickname;

    private String phone;

    @Email(message = "邮箱格式不正确")
    private String email;

    private String avatar;
}
