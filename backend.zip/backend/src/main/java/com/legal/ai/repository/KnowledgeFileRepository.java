package com.legal.ai.repository;

import com.legal.ai.entity.KnowledgeFile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KnowledgeFileRepository extends JpaRepository<KnowledgeFile, Long> {

    List<KnowledgeFile> findByUserIdOrderByCreatedAtDesc(Long userId);

    List<KnowledgeFile> findByUserIdAndFileNameContaining(Long userId, String keyword);
}
