package com.legal.ai.controller;

import com.legal.ai.dto.ApiResponse;
import com.legal.ai.entity.KnowledgeFile;
import com.legal.ai.service.KnowledgeFileService;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/api/knowledge")
public class KnowledgeController {

    private final KnowledgeFileService knowledgeFileService;

    public KnowledgeController(KnowledgeFileService knowledgeFileService) {
        this.knowledgeFileService = knowledgeFileService;
    }

    @GetMapping("/list/{userId}")
    public ResponseEntity<ApiResponse<List<KnowledgeFile>>> listFiles(@PathVariable Long userId) {
        List<KnowledgeFile> files = knowledgeFileService.getFilesByUserId(userId);
        return ResponseEntity.ok(ApiResponse.success(files));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<KnowledgeFile>>> searchFiles(
            @RequestParam Long userId,
            @RequestParam String keyword) {
        List<KnowledgeFile> files = knowledgeFileService.searchFiles(userId, keyword);
        return ResponseEntity.ok(ApiResponse.success(files));
    }

    @PostMapping("/upload")
    public ResponseEntity<ApiResponse<KnowledgeFile>> uploadFile(
            @RequestParam Long userId,
            @RequestParam MultipartFile file,
            @RequestParam(required = false) String description) {
        try {
            KnowledgeFile savedFile = knowledgeFileService.uploadFile(userId, file, description);
            return ResponseEntity.ok(ApiResponse.success(savedFile));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error("文件上传失败: " + e.getMessage()));
        }
    }

    @DeleteMapping("/{fileId}")
    public ResponseEntity<ApiResponse<String>> deleteFile(
            @PathVariable Long fileId,
            @RequestParam Long userId) {
        try {
            knowledgeFileService.deleteFile(fileId, userId);
            return ResponseEntity.ok(ApiResponse.success("文件删除成功"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()));
        }
    }

    @GetMapping("/download/{fileId}")
    public ResponseEntity<Resource> downloadFile(@PathVariable Long fileId) {
        KnowledgeFile knowledgeFile = knowledgeFileService.getFileById(fileId);
        try {
            Path filePath = Paths.get(knowledgeFile.getFilePath());
            Resource resource = new UrlResource(filePath.toUri());
            if (!resource.exists()) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + knowledgeFile.getFileName() + "\"")
                    .body(resource);
        } catch (MalformedURLException e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
