package com.legal.ai.controller;

import com.legal.ai.dto.ApiResponse;
import com.legal.ai.service.DeliLegalService;
import com.google.gson.JsonObject;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/legal")
public class LegalController {

    private final DeliLegalService deliLegalService;

    public LegalController(DeliLegalService deliLegalService) {
        this.deliLegalService = deliLegalService;
    }

    @PostMapping("/case/search")
    public ResponseEntity<ApiResponse<JsonObject>> searchCase(@RequestBody Map<String, Object> body) {
        try {
            String[] keywords;
            Object kw = body.get("keywords");
            if (kw instanceof java.util.List) {
                keywords = ((java.util.List<String>) kw).toArray(new String[0]);
            } else {
                keywords = new String[]{kw.toString()};
            }

            String longText = body.containsKey("longText") ? body.get("longText").toString() : null;
            int pageNo = body.containsKey("pageNo") ? Integer.parseInt(body.get("pageNo").toString()) : 1;
            int pageSize = body.containsKey("pageSize") ? Integer.parseInt(body.get("pageSize").toString()) : 5;
            String sortField = body.containsKey("sortField") ? body.get("sortField").toString() : "correlation";
            String sortOrder = body.containsKey("sortOrder") ? body.get("sortOrder").toString() : "desc";

            JsonObject result = deliLegalService.searchCase(keywords, longText, pageNo, pageSize, sortField, sortOrder);
            return ResponseEntity.ok(ApiResponse.success(result));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error("案例检索失败: " + e.getMessage()));
        }
    }

    @PostMapping("/law/search")
    public ResponseEntity<ApiResponse<JsonObject>> searchLaw(@RequestBody Map<String, Object> body) {
        try {
            String[] keywords;
            Object kw = body.get("keywords");
            if (kw instanceof java.util.List) {
                keywords = ((java.util.List<String>) kw).toArray(new String[0]);
            } else {
                keywords = new String[]{kw.toString()};
            }

            String fieldName = body.containsKey("fieldName") ? body.get("fieldName").toString() : "semantic";
            int pageNo = body.containsKey("pageNo") ? Integer.parseInt(body.get("pageNo").toString()) : 1;
            int pageSize = body.containsKey("pageSize") ? Integer.parseInt(body.get("pageSize").toString()) : 5;
            String sortField = body.containsKey("sortField") ? body.get("sortField").toString() : "correlation";
            String sortOrder = body.containsKey("sortOrder") ? body.get("sortOrder").toString() : "desc";

            JsonObject result = deliLegalService.searchLaw(keywords, fieldName, pageNo, pageSize, sortField, sortOrder);
            return ResponseEntity.ok(ApiResponse.success(result));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error("法规检索失败: " + e.getMessage()));
        }
    }

    @GetMapping("/law/{lawId}")
    public ResponseEntity<ApiResponse<JsonObject>> getLawInfo(@PathVariable String lawId) {
        try {
            JsonObject result = deliLegalService.getLawInfo(lawId, true);
            return ResponseEntity.ok(ApiResponse.success(result));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(ApiResponse.error("获取法规详情失败: " + e.getMessage()));
        }
    }
}
