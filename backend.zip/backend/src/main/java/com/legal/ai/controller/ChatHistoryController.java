package com.legal.ai.controller;

import com.legal.ai.dto.ApiResponse;
import com.legal.ai.entity.ChatHistory;
import com.legal.ai.service.ChatHistoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/chat")
public class ChatHistoryController {

    private final ChatHistoryService chatHistoryService;

    public ChatHistoryController(ChatHistoryService chatHistoryService) {
        this.chatHistoryService = chatHistoryService;
    }

    @GetMapping("/list/{userId}")
    public ResponseEntity<ApiResponse<List<ChatHistory>>> listHistories(@PathVariable Long userId) {
        List<ChatHistory> histories = chatHistoryService.getHistoriesByUserId(userId);
        return ResponseEntity.ok(ApiResponse.success(histories));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ChatHistory>> getHistory(
            @PathVariable Long id,
            @RequestParam Long userId) {
        ChatHistory history = chatHistoryService.getHistoryById(id, userId);
        return ResponseEntity.ok(ApiResponse.success(history));
    }

    @PostMapping("/create")
    public ResponseEntity<ApiResponse<ChatHistory>> createHistory(
            @RequestBody Map<String, Object> body) {
        Long userId = Long.valueOf(body.get("userId").toString());
        String title = body.get("title").toString();
        ChatHistory history = chatHistoryService.createHistory(userId, title);
        return ResponseEntity.ok(ApiResponse.success(history));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ChatHistory>> updateHistory(
            @PathVariable Long id,
            @RequestBody Map<String, Object> body) {
        Long userId = Long.valueOf(body.get("userId").toString());
        String title = body.containsKey("title") ? body.get("title").toString() : null;
        String messages = body.containsKey("messages") ? body.get("messages").toString() : null;
        ChatHistory history = chatHistoryService.updateHistory(id, userId, title, messages);
        return ResponseEntity.ok(ApiResponse.success(history));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<String>> deleteHistory(
            @PathVariable Long id,
            @RequestParam Long userId) {
        chatHistoryService.deleteHistory(id, userId);
        return ResponseEntity.ok(ApiResponse.success("会话删除成功"));
    }
}
