package com.legal.ai.service;

import com.legal.ai.entity.ChatHistory;
import com.legal.ai.repository.ChatHistoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ChatHistoryService {

    private final ChatHistoryRepository chatHistoryRepository;

    public ChatHistoryService(ChatHistoryRepository chatHistoryRepository) {
        this.chatHistoryRepository = chatHistoryRepository;
    }

    public List<ChatHistory> getHistoriesByUserId(Long userId) {
        return chatHistoryRepository.findByUserIdOrderByUpdatedAtDesc(userId);
    }

    public ChatHistory getHistoryById(Long id, Long userId) {
        return chatHistoryRepository.findByIdAndUserId(id, userId)
                .orElseThrow(() -> new RuntimeException("会话记录不存在"));
    }

    @Transactional
    public ChatHistory createHistory(Long userId, String title) {
        ChatHistory history = ChatHistory.builder()
                .title(title)
                .userId(userId)
                .messages("[]")
                .build();
        return chatHistoryRepository.save(history);
    }

    @Transactional
    public ChatHistory updateHistory(Long id, Long userId, String title, String messages) {
        ChatHistory history = getHistoryById(id, userId);

        if (title != null) {
            history.setTitle(title);
        }
        if (messages != null) {
            history.setMessages(messages);
        }

        return chatHistoryRepository.save(history);
    }

    @Transactional
    public void deleteHistory(Long id, Long userId) {
        ChatHistory history = getHistoryById(id, userId);
        chatHistoryRepository.delete(history);
    }
}
