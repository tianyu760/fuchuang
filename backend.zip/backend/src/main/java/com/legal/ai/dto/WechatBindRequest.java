package com.legal.ai.dto;

import lombok.Data;

@Data
public class WechatBindRequest {
    private String nickname;
    private String avatar;
}
