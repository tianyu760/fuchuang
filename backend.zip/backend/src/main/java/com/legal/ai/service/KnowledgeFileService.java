package com.legal.ai.service;

import com.legal.ai.entity.KnowledgeFile;
import com.legal.ai.repository.KnowledgeFileRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

@Service
public class KnowledgeFileService {

    private final KnowledgeFileRepository knowledgeFileRepository;

    @Value("${file.upload-dir}")
    private String uploadDir;

    public KnowledgeFileService(KnowledgeFileRepository knowledgeFileRepository) {
        this.knowledgeFileRepository = knowledgeFileRepository;
    }

    public List<KnowledgeFile> getFilesByUserId(Long userId) {
        return knowledgeFileRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public List<KnowledgeFile> searchFiles(Long userId, String keyword) {
        return knowledgeFileRepository.findByUserIdAndFileNameContaining(userId, keyword);
    }

    @Transactional
    public KnowledgeFile uploadFile(Long userId, MultipartFile file, String description) throws IOException {
        Path uploadPath = Paths.get(uploadDir, String.valueOf(userId));
        if (!Files.exists(uploadPath)) {
            Files.createDirectories(uploadPath);
        }

        String originalFileName = file.getOriginalFilename();
        String fileExtension = "";
        if (originalFileName != null && originalFileName.contains(".")) {
            fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
        }
        String storedFileName = UUID.randomUUID() + fileExtension;
        Path filePath = uploadPath.resolve(storedFileName);

        file.transferTo(filePath.toFile());

        String fileType = getFileType(originalFileName);

        KnowledgeFile knowledgeFile = KnowledgeFile.builder()
                .fileName(originalFileName)
                .filePath(filePath.toString())
                .fileSize(file.getSize())
                .fileType(fileType)
                .description(description)
                .userId(userId)
                .build();

        return knowledgeFileRepository.save(knowledgeFile);
    }

    @Transactional
    public void deleteFile(Long fileId, Long userId) {
        KnowledgeFile file = knowledgeFileRepository.findById(fileId)
                .orElseThrow(() -> new RuntimeException("文件不存在"));

        if (!file.getUserId().equals(userId)) {
            throw new RuntimeException("无权删除该文件");
        }

        // Delete physical file
        try {
            Files.deleteIfExists(Paths.get(file.getFilePath()));
        } catch (IOException e) {
            // Log warning but continue
        }

        knowledgeFileRepository.delete(file);
    }

    public KnowledgeFile getFileById(Long fileId) {
        return knowledgeFileRepository.findById(fileId)
                .orElseThrow(() -> new RuntimeException("文件不存在"));
    }

    private String getFileType(String fileName) {
        if (fileName == null) return "other";
        String lower = fileName.toLowerCase();
        if (lower.endsWith(".pdf")) return "pdf";
        if (lower.endsWith(".doc") || lower.endsWith(".docx")) return "doc";
        if (lower.endsWith(".xls") || lower.endsWith(".xlsx")) return "excel";
        if (lower.endsWith(".ppt") || lower.endsWith(".pptx")) return "ppt";
        if (lower.endsWith(".txt")) return "txt";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".gif")) return "image";
        if (lower.endsWith(".mp4") || lower.endsWith(".avi")) return "video";
        if (lower.endsWith(".zip") || lower.endsWith(".rar")) return "archive";
        return "other";
    }
}
