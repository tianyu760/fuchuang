package com.legal.ai.controller;

import com.legal.ai.dto.ApiResponse;
import com.legal.ai.dto.ChangePasswordRequest;
import com.legal.ai.dto.UserUpdateRequest;
import com.legal.ai.dto.WechatBindRequest;
import com.legal.ai.entity.User;
import com.legal.ai.service.AuthService;
import com.legal.ai.service.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private final UserService userService;
    private final AuthService authService;

    @Value("${file.upload-dir:./uploads}")
    private String uploadDir;

    public UserController(UserService userService, AuthService authService) {
        this.userService = userService;
        this.authService = authService;
    }

    @GetMapping("/me")
    public ResponseEntity<ApiResponse<User>> getCurrentUser() {
        User user = authService.getCurrentUser();
        user.setPassword(null);
        return ResponseEntity.ok(ApiResponse.success(user));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<User>> getUserById(@PathVariable Long id) {
        User user = userService.getUserById(id);
        user.setPassword(null);
        return ResponseEntity.ok(ApiResponse.success(user));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<User>> updateUser(@PathVariable Long id,
                                                         @RequestBody UserUpdateRequest request) {
        User user = userService.updateUser(id, request);
        user.setPassword(null);
        return ResponseEntity.ok(ApiResponse.success(user));
    }

    @PutMapping("/{id}/password")
    public ResponseEntity<ApiResponse<String>> changePassword(@PathVariable Long id,
                                                               @RequestBody ChangePasswordRequest request) {
        boolean success = userService.changePassword(id, request);
        if (success) {
            return ResponseEntity.ok(ApiResponse.success("密码修改成功"));
        }
        return ResponseEntity.badRequest().body(ApiResponse.error("原密码错误"));
    }

    @PostMapping("/{id}/avatar")
    public ResponseEntity<ApiResponse<User>> uploadAvatar(@PathVariable Long id,
                                                          @RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(ApiResponse.error("请选择要上传的文件"));
        }

        // 校验文件类型
        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            return ResponseEntity.badRequest().body(ApiResponse.error("只能上传图片文件"));
        }

        // 校验文件大小（最大5MB）
        if (file.getSize() > 5 * 1024 * 1024) {
            return ResponseEntity.badRequest().body(ApiResponse.error("图片大小不能超过5MB"));
        }

        try {
            // 创建上传目录
            Path avatarDir = Paths.get(uploadDir, "avatars");
            Files.createDirectories(avatarDir);

            // 生成唯一文件名
            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String filename = UUID.randomUUID().toString() + extension;

            // 保存文件
            Path filePath = avatarDir.resolve(filename);
            Files.copy(file.getInputStream(), filePath);

            // 更新用户头像URL
            String avatarUrl = "/uploads/avatars/" + filename;
            UserUpdateRequest updateRequest = new UserUpdateRequest();
            updateRequest.setAvatar(avatarUrl);
            User user = userService.updateUser(id, updateRequest);
            user.setPassword(null);

            return ResponseEntity.ok(ApiResponse.success(user));
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body(ApiResponse.error("头像上传失败：" + e.getMessage()));
        }
    }

    @PostMapping("/{id}/bind-wechat")
    public ResponseEntity<ApiResponse<User>> bindWechat(@PathVariable Long id,
                                                        @RequestBody WechatBindRequest request) {
        User user = userService.bindWechat(id, request.getNickname(), request.getAvatar());
        user.setPassword(null);
        return ResponseEntity.ok(ApiResponse.success(user));
    }

    @PostMapping("/{id}/unbind-wechat")
    public ResponseEntity<ApiResponse<User>> unbindWechat(@PathVariable Long id) {
        User user = userService.unbindWechat(id);
        user.setPassword(null);
        return ResponseEntity.ok(ApiResponse.success(user));
    }
}
