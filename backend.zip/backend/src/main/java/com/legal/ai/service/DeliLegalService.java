package com.legal.ai.service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

@Service
public class DeliLegalService {

    @Value("${deli.api.base-url}")
    private String baseUrl;

    @Value("${deli.api.appid}")
    private String appid;

    @Value("${deli.api.secret}")
    private String secret;

    private final OkHttpClient httpClient;
    private final Gson gson;

    public DeliLegalService() {
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build();
        this.gson = new Gson();
    }

    /**
     * 类案检索
     */
    public JsonObject searchCase(String[] keywords, String longText, int pageNo, int pageSize,
                                  String sortField, String sortOrder) throws IOException {
        JsonObject condition = new JsonObject();
        condition.add("keywordArr", gson.toJsonTree(keywords));
        if (longText != null && !longText.isEmpty()) {
            condition.addProperty("longText", longText);
        }
        condition.addProperty("sortField", sortField != null ? sortField : "correlation");
        condition.addProperty("sortOrder", sortOrder != null ? sortOrder : "desc");

        JsonObject body = new JsonObject();
        body.addProperty("pageNo", pageNo);
        body.addProperty("pageSize", pageSize);
        body.add("condition", condition);

        return doPost(baseUrl + "/queryListCase", body);
    }

    /**
     * 法规检索
     */
    public JsonObject searchLaw(String[] keywords, String fieldName, int pageNo, int pageSize,
                                 String sortField, String sortOrder) throws IOException {
        JsonObject condition = new JsonObject();
        condition.add("keywords", gson.toJsonTree(keywords));
        condition.addProperty("fieldName", fieldName != null ? fieldName : "semantic");

        JsonObject body = new JsonObject();
        body.addProperty("pageNo", pageNo);
        body.addProperty("pageSize", pageSize);
        body.addProperty("sortField", sortField != null ? sortField : "correlation");
        body.addProperty("sortOrder", sortOrder != null ? sortOrder : "desc");
        body.add("condition", condition);

        return doPost(baseUrl + "/queryListLaw", body);
    }

    /**
     * 法规详情
     */
    public JsonObject getLawInfo(String lawId, boolean merge) throws IOException {
        String url = baseUrl + "/lawInfo?lawId=" + lawId + "&merge=" + merge;
        return doGet(url);
    }

    private JsonObject doPost(String url, JsonObject body) throws IOException {
        RequestBody requestBody = RequestBody.create(
                body.toString(),
                MediaType.parse("application/json; charset=utf-8")
        );

        Request request = new Request.Builder()
                .url(url)
                .addHeader("appid", appid)
                .addHeader("secret", secret)
                .post(requestBody)
                .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (response.body() != null) {
                return gson.fromJson(response.body().string(), JsonObject.class);
            }
            throw new IOException("Empty response body");
        }
    }

    private JsonObject doGet(String url) throws IOException {
        Request request = new Request.Builder()
                .url(url)
                .addHeader("appid", appid)
                .addHeader("secret", secret)
                .addHeader("Content-Type", "application/json")
                .get()
                .build();

        try (Response response = httpClient.newCall(request).execute()) {
            if (response.body() != null) {
                return gson.fromJson(response.body().string(), JsonObject.class);
            }
            throw new IOException("Empty response body");
        }
    }
}
