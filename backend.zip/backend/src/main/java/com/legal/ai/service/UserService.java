package com.legal.ai.service;

import com.legal.ai.dto.ChangePasswordRequest;
import com.legal.ai.dto.UserUpdateRequest;
import com.legal.ai.entity.User;
import com.legal.ai.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public User getUserById(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new RuntimeException("用户不存在"));
    }

    @Transactional
    public User updateUser(Long id, UserUpdateRequest request) {
        User user = getUserById(id);

        if (request.getNickname() != null) {
            user.setNickname(request.getNickname());
        }
        if (request.getPhone() != null) {
            user.setPhone(request.getPhone());
        }
        if (request.getEmail() != null) {
            user.setEmail(request.getEmail());
        }
        if (request.getAvatar() != null) {
            user.setAvatar(request.getAvatar());
        }

        return userRepository.save(user);
    }

    @Transactional
    public boolean changePassword(Long id, ChangePasswordRequest request) {
        User user = getUserById(id);

        if (!passwordEncoder.matches(request.getOldPassword(), user.getPassword())) {
            return false;
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        return true;
    }

    @Transactional
    public User bindWechat(Long id, String nickname, String avatar) {
        User user = getUserById(id);
        user.setWechatOpenid("wx_" + UUID.randomUUID().toString().replace("-", "").substring(0, 16));
        user.setWechatNickname(nickname != null ? nickname : user.getNickname());
        user.setWechatAvatar(avatar);
        user.setWechatBound(true);
        // 如果用户没有自定义头像，使用微信头像
        if (user.getAvatar() == null || user.getAvatar().isEmpty()) {
            user.setAvatar(avatar);
        }
        return userRepository.save(user);
    }

    @Transactional
    public User unbindWechat(Long id) {
        User user = getUserById(id);
        user.setWechatOpenid(null);
        user.setWechatNickname(null);
        user.setWechatAvatar(null);
        user.setWechatBound(false);
        return userRepository.save(user);
    }
}
