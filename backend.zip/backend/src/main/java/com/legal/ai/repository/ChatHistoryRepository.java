package com.legal.ai.repository;

import com.legal.ai.entity.ChatHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ChatHistoryRepository extends JpaRepository<ChatHistory, Long> {

    List<ChatHistory> findByUserIdOrderByUpdatedAtDesc(Long userId);

    Optional<ChatHistory> findByIdAndUserId(Long id, Long userId);
}
